import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ConceptsComponent } from './concepts/concepts.component';
import { BlogComponent } from './blog/blog.component';
import { AboutComponent } from './about/about.component';
import { AddPostComponent } from './blog/add-post/add-post.component';
import { PostDetailsComponent } from './blog/post-details/post-details.component';
import { AuthGuard } from './shared/guards/auth.guard';

// configure the routes
const routes: Routes = [
  { path: '', component: ConceptsComponent },
  { path: 'concepts', component: ConceptsComponent },
  {
    path: 'blog', children: [
      { path: '', component: BlogComponent },
      { path: 'new', component: AddPostComponent },
      { path: ':id', component: PostDetailsComponent }
    ]
  },
  { path: 'about', component: AboutComponent, canActivate: [AuthGuard] }  // check auth guard --it returns true
];

@NgModule({
  imports: [RouterModule.forRoot(routes)], // registering the routes 
  exports: [RouterModule]
})
export class AppRoutingModule { }
