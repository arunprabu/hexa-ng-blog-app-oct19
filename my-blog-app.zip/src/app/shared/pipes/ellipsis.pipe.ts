import { Pipe, PipeTransform } from '@angular/core';

//Decorator
@Pipe({
  name: 'ellipsis'  //name of the pipe
})
export class EllipsisPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    if (args) {
      value = value.substr(0, args[0])
    }
    return value + "...";
  }

}
