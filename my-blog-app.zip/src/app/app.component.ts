import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',  // html 
  styleUrls: ['./app.component.css'] //css
})
export class AppComponent {
  //ts 
  title = 'my-blog-app';
}
