import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { CebComponent } from './ceb/ceb.component';

@Component({
  selector: 'app-concepts',
  templateUrl: './concepts.component.html',
  styles: [
    `
    .redText{
      color: red;
    }

    .boldText{
      font-weight: bold;
    }

    `
  ]
})
export class ConceptsComponent implements OnInit, AfterViewInit {

  //ideal place for variables 
  //string interpolation related 
  appName: string = "My Blog App";
  skillsList: Array<string> = [
    'html', 'css', 'dot net'
  ];

  isLoggedIn: boolean = false;
  age: number = 10;

  // property binding 
  devName: string = "Arun";

  //two way binding 
  course: string = "Angular";

  // view child related 
  @ViewChild(CebComponent, { static: false }) cebData: any;


  constructor() {

  }

  ngOnInit() {
  }

  ngAfterViewInit() {
    console.log("Inside ngAfter View Init");
    console.log(this.cebData);
  }

  //ideal place for methods
  isAuth() {
    return this.isLoggedIn;
  }

  //event binding related 
  onBtnClickHandler() {
    alert("test");
  }


  //custom prop binding related
  getAge() {
    return this.age;
  }

  // custom event related 
  onProfileLoadedHandler(dataFromChildComp: any) {
    console.log(dataFromChildComp);
  }
}
