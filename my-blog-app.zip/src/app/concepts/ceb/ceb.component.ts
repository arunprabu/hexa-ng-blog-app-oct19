import { Component, OnInit, EventEmitter, Output, ViewChild } from '@angular/core';

@Component({
  selector: 'app-ceb',
  templateUrl: './ceb.component.html',
  styles: []
})
export class CebComponent implements OnInit {

  //Step 1. Create Custom Event 
  @Output() onProfileLoaded = new EventEmitter();

  @ViewChild('f', { static: true }) formData: any;

  profileData: any;

  constructor() {
    console.log("Inside Constructor");
    this.profileData = {
      name: "Arun",
      city: "chennai"
    }
  }

  ngOnInit() { // life cycle hook 
    console.log("Inside ngOnInit");
  }

  onBtnClick() {
    //Step 2. Emit the event thru program 
    this.onProfileLoaded.emit(this.profileData);  // Step 3. Pass the data as event Object 
  }

  onMsgBtnSubmitHandler() {
    console.log(this.formData);
  }
}
