import { Directive, ElementRef, Renderer2, HostListener } from '@angular/core';

//Decorator
@Directive({
  selector: '[appColorizer]'  // attribute selector
})
export class ColorizerDirective {

  //Dependency Injection
  constructor(private elementRef: ElementRef,
    private renderer: Renderer2) {
    console.log("Inside Constructor in Directive");

    console.log(this.elementRef.nativeElement);
    let divEl: any = this.elementRef.nativeElement;
    // Using JS -- not recommended
    // divEl.style.backgroundColor = "red";
    // divEl.style.height = "200px";

    //Using Angular's Renderer2
    this.renderer.setStyle(divEl, 'background-color', 'red');
    this.renderer.setStyle(divEl, 'height', '200px');
  }

  @HostListener('click', ['$event.target'])
  onElementClick(element) {
    console.log(element);
    this.renderer.setStyle(element, 'background-color', 'yellow');
  }

}
