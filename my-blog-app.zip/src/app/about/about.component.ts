import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styles: []
})
export class AboutComponent implements OnInit {

  today: Date = new Date();

  dummyText = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis quas aperiam ipsam amet molestias dicta minima fuga, officia doloremque non nostrum enim nisi distinctio tenetur quod provident sit iure nesciunt?';

  constructor() { }

  ngOnInit() {
  }

}
