import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Post } from './post';

//Decorator -- will make the service dep injectable
@Injectable({
  providedIn: 'root'
})
export class BlogService {

  REST_API_URL = 'https://jsonplaceholder.typicode.com/posts';

  constructor(private http: HttpClient) { }

  //1: get the data from component
  createPost(postFormData: any) {
    console.log(postFormData);
    //2: send the above data to rest api 
    //2.1 identify the rest api url
    //2.2 send the data to rest api using POST method
    let promise = new Promise((resolve, reject) => {
      this.http.post(this.REST_API_URL, postFormData)
        .toPromise()
        .then((res: Post) => { // 3. receive the resp from rest api 
          console.log(res);

          //4. send the resp to the component 
          resolve(res); // upon promise fullfilled 
        })
        .catch((err) => {
          console.log(err);
          reject(err); // not fullfilled 
        })
        .finally(() => {
          console.log("It's over");
        });
    });

    return promise as Promise<Post>; // will ensure the res hits the component
  }

  getPosts() {
    //1. get the req from comp
    //2. send the req to rest api -- GET 
    return this.http.get(this.REST_API_URL)
      .pipe(map((res: Post[]) => { // 3. receive  resp 
        console.log(res);
        return res; //4. send it back to the comp 
      }));
  }

  getPostById(id: string) { //1. get the req from comp
    console.log(id);
    let _url = this.REST_API_URL + '/' + id;
    //2. send the req to rest api -- GET 
    return this.http.get(_url)
      .pipe(map((res: Post) => { // 3. receive  resp 
        console.log(res);
        return res; //4. send it back to the comp 
      }));
  }

  updatePostById(postData) {
    console.log(postData);

    //2: send the above data to rest api 
    //2.1 identify the rest api url
    //2.2 send the data to rest api using POST method
    let promise = new Promise((resolve, reject) => {
      let _url = this.REST_API_URL + '/' + postData.id;
      this.http.put(_url, postData)
        .toPromise()
        .then((res: Post) => { // 3. receive the resp from rest api 
          console.log(res);

          //4. send the resp to the component 
          resolve(res); // upon promise fullfilled 
        })
        .catch((err) => {
          console.log(err);
          reject(err); // not fullfilled 
        })
        .finally(() => {
          console.log("It's over");
        });
    });

    return promise as Promise<Post>;  // will ensure the res hits the component
  }

  deletePostById(id: any) {
    console.log(id);
    let promise = new Promise((resolve, reject) => {
      let _url = this.REST_API_URL + '/' + id;
      this.http.delete(_url)
        .toPromise()
        .then((res: any) => {
          //3. receive the response from rest api
          console.log(res);
          //4. send the response to the component
          resolve(res); //this happens if the promise is fullfilled
        })
        .catch((err) => {
          console.log(err);
          reject(err);
        })
        .finally(() => {
          console.log("It's deleted");
        });
    });
    return promise;

  }
}
