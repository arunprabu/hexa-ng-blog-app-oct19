export interface IPost {
    id: string,
    title: string,
    body: string
}

export class Post implements IPost {
    id: string;
    title: string;
    body: string;
}
