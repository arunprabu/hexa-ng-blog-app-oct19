import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { BlogService } from '../blog.service';
import { Post } from '../post';

@Component({
  selector: 'app-add-post',
  templateUrl: './add-post.component.html',
  styles: []
})
export class AddPostComponent implements OnInit {

  //Step 1: Create FormGroup 
  postForm: FormGroup;
  isSaved: boolean;

  constructor(private blogService: BlogService) {
    //Step1 -- continues
    this.postForm = new FormGroup({
      // Step 2: create form controls
      title: new FormControl('', Validators.required),
      content: new FormControl('', Validators.required)
    });
  }

  ngOnInit() {
  }

  async onSubmitHandler() {
    console.log(this.postForm.value);

    //1. send the above data to service
    let status: Post = await this.blogService.createPost(this.postForm.value);
    console.log(status);  //2. receive the response from services
    if (status && status.id) {
      this.isSaved = true;
    } else {
      this.isSaved = false;
    }

  }
}
