import { Component, OnInit, OnDestroy } from '@angular/core';
import { BlogService } from './blog.service';
import { Subscription } from 'rxjs';
import { Post } from './post';

@Component({
  selector: 'app-blog',
  templateUrl: './blog.component.html',
  styles: []
})
export class BlogComponent implements OnInit, OnDestroy {

  postList: Post[];
  postListSubscription: Subscription;

  constructor(private blogService: BlogService) { }

  ngOnInit() {
    //ideal place for any ajax calls
    this.postListSubscription = this.blogService.getPosts()
      .subscribe((res: Post[]) => {
        console.log(res);
        this.postList = res;
      });
  }

  ngOnDestroy() {
    console.log("Inside Destroy");
    //ideal place for unsubscribe and clearing the data
    this.postListSubscription.unsubscribe();
    if (this.postList && this.postList.length > 0) {
      this.postList.length = 0;
    }
  }

}
