import { Component, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { BlogService } from '../blog.service';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { Post } from '../post';

@Component({
  selector: 'app-post-details',
  templateUrl: './post-details.component.html',
  styles: []
})
export class PostDetailsComponent implements OnInit, OnDestroy {
  postData: Post;
  duplicatePostData: Post;
  isSaved: boolean;
  postSubscription: Subscription;

  @ViewChild('deleteBtn', { static: false }) deleteBtnEl: ElementRef;

  constructor(private blogService: BlogService,
    private route: ActivatedRoute) { }

  ngOnInit() {
    // read url params in angular 6, 7, 8 -- stackoverflow
    let _id = this.route.snapshot.paramMap.get('id');

    this.postSubscription = this.blogService.getPostById(_id)
      .subscribe((res: Post) => {
        console.log(res);
        this.postData = res;
      });
  }

  onEditModalOpen() {
    this.duplicatePostData = JSON.parse(JSON.stringify(this.postData));
  }

  async onUpdateHandler() {
    console.log(this.duplicatePostData);
    let status: Post = await this.blogService.updatePostById(this.duplicatePostData);
    console.log(status);
    if (status && status.id) {
      this.isSaved = true;
      this.postData = status;
    } else {
      this.isSaved = false;
    }
  }

  ngOnDestroy() {
    console.log("Inside destroy");
    this.postSubscription.unsubscribe();
  }

  async onDeleteHandler(id: any) {
    console.log(id);
    let status = await this.blogService.deletePostById(id);

    if (status != null) {
      console.log(this.deleteBtnEl.nativeElement);
      let el = this.deleteBtnEl.nativeElement;
      el.innerText = "Deleted! Will redirect in a few seconds";
      setTimeout(() => {
        //redirect 
      }, 3000);
    }
  }
}
